package PageObject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class HomePage {
	private static WebElement element = null;
	private WebDriver driver;
	
	//String subCTN="4695107160";
	//String userName="opusapi01";
	//String userPass="unix11";
	String url = "http://istapi-a.hydc.sbc.com:3900/mi/";
	
	
	By userName = By.id("");
	By password = By.id("");
	
	
	
	public HomePage(WebDriver driver){
		this.driver=driver;
	}
	
	public static WebElement userName(WebDriver driver){
		 element = driver.findElement(By.id(""));
		 return element;
	}
	
	public static WebElement password(WebDriver driver){
		 element = driver.findElement(By.id(""));
		 return element;
	}
	
}
