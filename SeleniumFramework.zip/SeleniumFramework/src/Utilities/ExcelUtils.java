package Utilities;

import java.io.FileInputStream;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelUtils {
	private static XSSFWorkbook excelBook;
	private static XSSFSheet excelSheet;	
	private static XSSFRow excelRow;
	private static XSSFCell excelCell;
	
	public static void getFile(String filePath, String sheetName) throws Exception{
		try{
			
			FileInputStream ExcelFile = new FileInputStream(filePath);
			excelBook = new XSSFWorkbook(ExcelFile);
			excelSheet = excelBook.getSheet(sheetName);
			
		}catch(Exception e){
			throw(e);
		}
	}
	
	
	public static String getCellData(int rowNum, int colNum) throws Exception{
		try{
			String cellData;
			
			excelRow = excelSheet.getRow(rowNum);
			excelCell = excelRow.getCell(colNum, Row.RETURN_BLANK_AS_NULL);
			
			cellData =  (String) excelCell.getRawValue();
			return cellData;
		}catch(Exception e){
			throw(e);
		}
	}
	
	public void ElementOperation(String locator, String Value, String operation){
		
	}
	
	public void ElementOperation(String locator, String locatorValue, String operation, String operationValue){
		
	}

}
