package com.sam.selenium;

import org.testng.annotations.Test;

import PageObject.HomePage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import Utilities.ExcelUtils;



public class SeleniumMain {
	private static WebDriver driver;
	static{
		try {
			ExcelUtils.getFile("C:\\Users\\sm990y\\Downloads\\eclipse-jee-neon-2-win32-x86_64\\dataSheet.xlsx","Sheet1");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.setProperty("webdriver.ie.driver", "C:\\Users\\sm990y\\Downloads\\eclipse-jee-neon-2-win32-x86_64\\IEDriverServer.exe");
		//String driverPath = "C:\\Users\\sm990y\\Downloads\\eclipse-jee-neon-2-win32-x86_64";
		//System.setProperty("webdriver.gecko.driver", driverPath);
		@SuppressWarnings("unused")
		WebDriver driver;
		driver = new InternetExplorerDriver();
	}
	@Test	
	public void test1() throws Exception {	
		
		HomePage hp = new HomePage(SeleniumMain.driver);
		
		
		
	}

}
